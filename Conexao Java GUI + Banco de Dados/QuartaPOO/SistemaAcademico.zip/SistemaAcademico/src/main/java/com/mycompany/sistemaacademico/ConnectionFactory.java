package com.mycompany.sistemaacademico;

import java.sql.Connection;
import java.sql.DriverManager;

public class ConnectionFactory {
    private static String host = 
       "mysql-31fb8d5a-poo-imt.h.aivencloud.com"; //localhost
    private static String porta = "13661"; //3306
    private static String db = "sistema_academico";
    private static String usuario = "avnadmin"; // root
    private static String senha = 
            "AVNS_WI_jIoTwQCNqA8R3mUl"; //imtdb
    
    public static Connection obterConexao()
          throws Exception {
        String url = "jdbc:mysql://" + host + 
                ":" + porta + "/" + db;
        return DriverManager.getConnection(
                url,usuario,senha);
    }  
}
