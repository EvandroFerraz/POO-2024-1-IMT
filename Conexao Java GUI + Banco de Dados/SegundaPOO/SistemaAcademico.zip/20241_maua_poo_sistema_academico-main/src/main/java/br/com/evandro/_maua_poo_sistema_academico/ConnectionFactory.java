package br.com.evandro._maua_poo_sistema_academico;

import java.sql.Connection;
import java.sql.DriverManager;

public class ConnectionFactory {
    private static String host = 
       "mysql2104-poo-2204.h.aivencloud.com";
    private static String porta = "25407";
    private static String db = "sistema_academico";
    private static String usuario = "avnadmin";
    private static String senha = 
            "AVNS_jDBH9IQHG5HN41EEs_r";
    
    public static Connection obterConexao()
        throws Exception{
        String url = String.format(
           "jdbc:mysql://%s:%s/%s", host,
           porta, db
        );
        return DriverManager.getConnection(url, 
                usuario, senha);
    }
}
