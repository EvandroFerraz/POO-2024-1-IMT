/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.exercicio1;

/**
 *
 * @author ferra
 */
public class Exercicio1 {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
